
package com.rbc.schedule.jobapi.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class JobCreateRequest {
    private String jobName;
    private String jobType;
    private String environment;
    private LocalDateTime schedulerStartTime;
    private LocalDateTime schedulerEndTime;
    private Long parentJobId;
}
