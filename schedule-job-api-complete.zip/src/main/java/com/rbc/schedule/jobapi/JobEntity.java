
package com.rbc.schedule.jobapi;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "schedule_job")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class JobEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long jobId;

    private String jobName;
    private String jobType;
    private String environment;
    private String status;

    private LocalDateTime createDatetime;
    private LocalDateTime updatedDatetime;
    private LocalDateTime schedulerStartTime;
    private LocalDateTime schedulerEndTime;

    private Integer retryCount;
    private String failureCode;
    private String failureErrorMessage;
    private LocalDateTime failureDatetime;

    private String summary;
    private Long parentJobId;
}
