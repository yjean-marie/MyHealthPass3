
package com.rbc.schedule.jobapi.controller;

import com.rbc.schedule.jobapi.*;
import com.rbc.schedule.jobapi.dto.*;
import com.rbc.schedule.jobapi.service.JobService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/jobs")
@RequiredArgsConstructor
public class JobController {

    private final JobService jobService;

    @PostMapping
    public ResponseEntity<JobEntity> createJob(@RequestBody JobCreateRequest request) {
        return ResponseEntity.ok(jobService.createJob(request));
    }

    @PutMapping("/{jobId}")
    public ResponseEntity<JobEntity> updateJob(@PathVariable Long jobId, @RequestBody JobUpdateRequest request) {
        return ResponseEntity.ok(jobService.updateJob(jobId, request));
    }

    @GetMapping("/job-status/{jobId}")
    public ResponseEntity<JobStatusResponse> getJobStatus(@PathVariable Long jobId) {
        return ResponseEntity.ok(jobService.getJob(jobId));
    }
}
