
package com.rbc.schedule.jobapi.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class JobUpdateRequest {
    private String status;
    private LocalDateTime updatedDatetime;
    private LocalDateTime schedulerEndTime;
    private String failureCode;
    private String failureErrorMessage;
    private LocalDateTime failureDatetime;
    private Integer retryCount;
    private String summary;
}
