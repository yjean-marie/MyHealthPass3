
package com.rbc.schedule.jobapi.service;

import com.rbc.schedule.jobapi.*;
import com.rbc.schedule.jobapi.dto.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class JobService {

    private final JobRepository jobRepository;

    public JobEntity createJob(JobCreateRequest request) {
        JobEntity job = JobEntity.builder()
                .jobName(request.getJobName())
                .jobType(request.getJobType())
                .environment(request.getEnvironment())
                .status("STARTED")
                .createDatetime(LocalDateTime.now())
                .schedulerStartTime(request.getSchedulerStartTime())
                .schedulerEndTime(request.getSchedulerEndTime())
                .retryCount(0)
                .parentJobId(request.getParentJobId())
                .build();
        return jobRepository.save(job);
    }

    public JobEntity updateJob(Long jobId, JobUpdateRequest request) {
        JobEntity job = jobRepository.findById(jobId)
                .orElseThrow(() -> new RuntimeException("Job not found"));
        job.setStatus(request.getStatus());
        job.setUpdatedDatetime(LocalDateTime.now());
        job.setSchedulerEndTime(request.getSchedulerEndTime());
        job.setFailureCode(request.getFailureCode());
        job.setFailureErrorMessage(request.getFailureErrorMessage());
        job.setFailureDatetime(request.getFailureDatetime());
        job.setRetryCount(request.getRetryCount());
        job.setSummary(request.getSummary());
        return jobRepository.save(job);
    }

    public JobStatusResponse getJob(Long jobId) {
        JobEntity job = jobRepository.findById(jobId)
                .orElseThrow(() -> new RuntimeException("Job not found"));
        JobStatusResponse response = new JobStatusResponse();
        response.setJobId(job.getJobId());
        response.setJobName(job.getJobName());
        response.setJobType(job.getJobType());
        response.setEnvironment(job.getEnvironment());
        response.setStatus(job.getStatus());
        response.setCreateDatetime(job.getCreateDatetime());
        response.setUpdatedDatetime(job.getUpdatedDatetime());
        response.setSchedulerStartTime(job.getSchedulerStartTime());
        response.setSchedulerEndTime(job.getSchedulerEndTime());
        response.setRetryCount(job.getRetryCount());
        response.setFailureCode(job.getFailureCode());
        response.setFailureErrorMessage(job.getFailureErrorMessage());
        response.setFailureDatetime(job.getFailureDatetime());
        response.setSummary(job.getSummary());
        response.setParentJobId(job.getParentJobId());
        return response;
    }
}
