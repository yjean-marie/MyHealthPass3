
package com.rbc.schedule.jobapi.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class JobStatusResponse {
    private Long jobId;
    private String jobName;
    private String jobType;
    private String environment;
    private String status;
    private LocalDateTime createDatetime;
    private LocalDateTime updatedDatetime;
    private LocalDateTime schedulerStartTime;
    private LocalDateTime schedulerEndTime;
    private Integer retryCount;
    private String failureCode;
    private String failureErrorMessage;
    private LocalDateTime failureDatetime;
    private String summary;
    private Long parentJobId;
}
