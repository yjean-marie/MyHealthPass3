
package com.rbc.schedule.jobapi;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbc.schedule.jobapi.controller.JobController;
import com.rbc.schedule.jobapi.dto.JobCreateRequest;
import com.rbc.schedule.jobapi.dto.JobStatusResponse;
import com.rbc.schedule.jobapi.dto.JobUpdateRequest;
import com.rbc.schedule.jobapi.service.JobService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(JobController.class)
public class JobControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private JobService jobService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void createJob_ShouldReturn200() throws Exception {
        JobCreateRequest req = new JobCreateRequest();
        req.setJobName("test-job");
        req.setJobType("notification");
        req.setEnvironment("DEV");

        JobEntity mockJob = JobEntity.builder().jobId(100L).jobName("test-job").status("STARTED").build();
        when(jobService.createJob(any())).thenReturn(mockJob);

        mockMvc.perform(post("/jobs")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.jobId").value(100));
    }

    @Test
    void getJobStatus_ShouldReturnJob() throws Exception {
        JobStatusResponse res = new JobStatusResponse();
        res.setJobId(101L);
        res.setStatus("SUCCESS");

        when(jobService.getJob(101L)).thenReturn(res);

        mockMvc.perform(get("/jobs/job-status/101"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("SUCCESS"));
    }
}
