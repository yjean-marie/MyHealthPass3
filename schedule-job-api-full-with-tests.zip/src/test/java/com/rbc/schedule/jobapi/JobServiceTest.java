
package com.rbc.schedule.jobapi;

import com.rbc.schedule.jobapi.dto.JobCreateRequest;
import com.rbc.schedule.jobapi.dto.JobUpdateRequest;
import com.rbc.schedule.jobapi.service.JobService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class JobServiceTest {

    private JobRepository jobRepository;
    private JobService jobService;

    @BeforeEach
    void setUp() {
        jobRepository = mock(JobRepository.class);
        jobService = new JobService(jobRepository);
    }

    @Test
    void createJob_ShouldSetDefaults() {
        JobCreateRequest request = new JobCreateRequest();
        request.setJobName("streamline");
        request.setJobType("notification");
        request.setEnvironment("UAT");

        JobEntity savedJob = JobEntity.builder()
                .jobId(1L)
                .jobName("streamline")
                .jobType("notification")
                .environment("UAT")
                .status("STARTED")
                .retryCount(0)
                .build();

        when(jobRepository.save(any())).thenReturn(savedJob);

        JobEntity result = jobService.createJob(request);
        assertEquals("STARTED", result.getStatus());
        assertEquals(0, result.getRetryCount());
    }

    @Test
    void updateJob_ShouldUpdateFields() {
        JobEntity job = new JobEntity();
        job.setJobId(1L);
        job.setStatus("STARTED");

        when(jobRepository.findById(1L)).thenReturn(Optional.of(job));
        when(jobRepository.save(any())).thenAnswer(i -> i.getArguments()[0]);

        JobUpdateRequest update = new JobUpdateRequest();
        update.setStatus("FAILED");
        update.setRetryCount(1);
        update.setFailureCode("ERR");
        update.setFailureErrorMessage("Failure");

        JobEntity result = jobService.updateJob(1L, update);
        assertEquals("FAILED", result.getStatus());
        assertEquals(1, result.getRetryCount());
        assertEquals("ERR", result.getFailureCode());
    }
}
